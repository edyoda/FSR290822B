


// json string --- js object :---   JSON.parse

// js object --- json string :---- JSON.stringify

var obj = {
    name : "abc",
    email : "abc@gmail.com",
    contact : 87654
}

console.log(typeof(obj))
var final_output = JSON.stringify(obj)
console.log(typeof(final_output))
var final_js_obj = JSON.parse(final_output)
console.log(typeof(final_js_obj))


// console.log(this.responseText)

// onreadystatechange
// Defines a function to be called when the readyState property changes
// readyState
// Holds the status of the XMLHttpRequest.
// 0: request not initialized
// 1: server connection established
// 2: request received
// 3: processing request
// 4: request finished and response is ready status
// 200: "OK"
// 403: "Forbidden"
// 404: "Page not found"
//201 : "post successfully created"


// var productload = ()=>{
//     var a = new XMLHttpRequest();
//     a.open('GET','https://fakestoreapi.com/products/',true)
//     a.send()
//     a.onreadystatechange = function(){
//         if(this.status == 200 && this.readyState == 4){
//             // console.log(this.responseText)
//             var data = JSON.parse(this.responseText)
//             // console.log(data)
//             for(var j =0;j<data.length;j++){
//                 // console.log(data[j])
//                 var div_tag = document.createElement('div')
//                 div_tag.className = "product_div"
//                 for(var i in data[j]){
//                     // console.log(data[j][i])
//                     if(i=="image"){
//                         var img_tag = document.createElement('img');
//                         img_tag.src = data[j][i]
//                         // console.log(img_tag)
//                         img_tag.className = "img_style"
//                         div_tag.appendChild(img_tag)
//                     }
//                     else{
//                         div_tag.innerHTML += "<br>"+i+" --- "+data[j][i]+"<br><br>"
//                     }
                   
                  
//                 }
//                 // console.log(div_tag)
//                 document.getElementById('demo1').appendChild(div_tag)
//             }
//         }
//     }

// }

// productload();

// // div_tag.innerHTML += data[j][i]+"<br><br>"





var  postObj = {
    id:1,
    title : "Hello javascript",
    body : "we are doing ajax in javascript"
}

var post = JSON.stringify(postObj)

var url = 'https://jsonplaceholder.typicode.com/posts';
var x = new XMLHttpRequest();
x.open("POST",url,true)
x.setRequestHeader('Content-type' ,'application/json');
x.send(post)


x.onreadystatechange = function(){
    if(x.status === 201){
        // console.log("post successfully created !")
        console.log(this.responseText)
    }
}





























