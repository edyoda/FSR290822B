// class Apple{
//     config1(){
//        console.log("m2 512gb");
//     }
//     config2(){
//         console.log("m1 256gb");
//     }
//     color(laptop_color){
//         console.log(laptop_color)
//     }
//     inch(){
//         var a = prompt("Enter inch");
//         console.log(a)
//     }
// }

// var mackbook_air1 = new Apple();
// mackbook_air1.config1();
// mackbook_air1.color("starlight");
// mackbook_air1.inch();

// var macbook_pro1 = new Apple();
// macbook_pro1.config2();
// macbook_pro1.color("gold");
// macbook_pro1.inch();




// class humans{
//     constructor(){
//         console.log("eat sleep walk repeat")   
//     }
//     dance(){
//         console.log("demo data for dance")
//     }
//     swiming(){
//         console.log("demo data for swiming")
//     }
// }

// var roshni = new humans();
// roshni.dance()
// var rafik = new humans();
// rafik.swiming()
// var sumit = new humans();
// sumit.dance()
// var teja = new humans();




// class std_info{
//     constructor(name,age){
//         console.log(name,age)
//     }
//     test_marks(Maths){
//         console.log("Maths Marks : "+Maths)
//     }
// }

// var std1 = new std_info("john",12);
// std1.test_marks(50)
// var std2 = new std_info("tom",13);
// std2.test_marks(90)




// var arr1 = [11,12,13,14,15,16,17,18,19,20]

// class read_arr{
//     constructor(x){
//         // console.log(x)
//         this.val =  x
//     }
//     even_num(){
//         // console.log("from even num " +this.val)
//        var ans1 =  this.val.filter((element)=>{
//             return element%2==0
//         })
//         console.log(this.val)
//         console.log(ans1)
//     }
//     odd_num(){
//     //console.log("from odd num "+this.val) 
//     var ans2 = this.val.filter((element)=>{
//         return element%2!=0
//     })
//     console.log(this.val)
//     console.log(ans2)


//     }
      
// }

// var read_arr1 = new read_arr(arr1);
// read_arr1.even_num()
// read_arr1.odd_num()





let students_info = [
	{
		name : "abc",
		email : "abc@gmail.com",
		subject : "python",
		marks : 60
	},
	{
		name : "pqr",
		email : "pqr@gmail.com",
		subject : "js",
		marks : 30
	},
	{
		name : "mno",
		email : "mno@gmail.com",
		subject : "js",
		marks : 70
	},
	{
		name : "xyz",
		email : "xyz@gmail.com",
		subject : "php",
		marks : 90
	},
	{
		name : "asw",
		email : "asw@gmail.com",
		subject : "php",
		marks : 24
	}
]

class demo{
    constructor(y){
        // console.log(y)
        this.val = y
    }
    read_name(){
       var ans1 = this.val.map((element)=>{
            return element.name
        })
        console.log(ans1)
    }
    read_sub(){
      var ans2=this.val.map((element)=>{
            return element.subject
        })
        console.log(ans2)
    }
}
var demo_obj1 = new demo(students_info)
demo_obj1.read_name()
demo_obj1.read_sub()


// var arr2 = [10,11,13,15,17,20,30]
// var demo_ans = arr2.map((element)=>{
//     return element*2
//     // return element%2==0
// })
// console.log(arr2)
// console.log(demo_ans)














































