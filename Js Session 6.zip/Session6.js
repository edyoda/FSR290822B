
var City_Name = Array("California","Paris","Barcelona");
console.log(City_Name);
console.log(typeof(City_Name));

//					 0.          1.       2	
var City_Name = ["California","Paris","Barcelona"]
console.log(City_Name)
console.log(typeof(City_Name));


//.              0. 1. 2. 3. 4    
var arr_demo = [10,20,30,40,50]
document.write(arr_demo+"<br>");
document.write(arr_demo[0]+"<br>");
document.write(arr_demo[1]+"<br>");
document.write(arr_demo[2]+"<br>");
document.write(arr_demo[3]+"<br>");
document.write(arr_demo[4]+"<br>");

//			0.  1. 2 -------------------3----------------------------   4. 5	
//					   0.  1.  2. ------3-----------------------   4
//									0. 1 ----------2-----------
//                                              0.         1
//										   0123456789 	012
var arr1 = [10,20,30,["a","b","c",[40,50,["Javascript","Python"]],"d"],60,70]
// a,b,c,40,50,Javascript,d
//a
//40,50
//d
//Javascript
//java

document.write(arr1[3]+"<br>");
document.write(arr1[3][0]+"<br>");
document.write(arr1[3][3][0]+" "+arr1[3][3][1]+"<br>");
document.write(arr1[3][4]+"<br>");
document.write(arr1[3][3][2][0]+"<br>");
document.write(arr1[3][3][2][0][0]+arr1[3][3][2][0][1]+arr1[3][3][2][0][2]+arr1[3][3][2][0][3]+"<br>")

var a=arr1[3][3][2][0];
var b=arr1[3][3][2][1];
var a= a.slice(4);
var b= b.slice(0,2);
document.write(b+a);

document.write(arr1[3][3][2][1][0]+""+arr1[3][3][2][1][1]+""+arr1[3][3][2][0][4]+""+arr1[3][3][2][0][5]+""+arr1[3][3][2][0][6]+""+arr1[3][3][2][0][7]+""+arr1[3][3][2][0][8]+""+arr1[3][3][2][0][9]+"<br>");


//Pyscript*/




var City_Name = ["California","Paris","Barcelona"] 
var arr_len = City_Name.length;
console.log(arr_len);


var City_Name = ["California","Paris","Barcelona"] 
var reversedArray = City_Name.reverse();
console.log(reversedArray);


var num1_arr = [10,20,30] 
var reversedArray = num1_arr.reverse();
console.log(reversedArray);



var arr_message = ["Javascript","is","fun."]
console.log(arr_message);
var joinedMessage = arr_message.join(" ");
console.log(joinedMessage);
console.log(typeof(joinedMessage));




var City_Name = ["london","California","Paris","Barcelona","New York"] 
// var removedCity = City_Name.pop()
// console.log(City_Name)
// console.log(removedCity)
var x = City_Name.pop()
console.log(x)
// City_Name.shift()
console.log(City_Name)


var City_Name = ["California","Paris","Barcelona"] 
City_Name.unshift("Boston");
City_Name.push("Chicago");
console.log(City_Name)



var odd_num = [1,3,5,7]
var even_num =[2,4,6,8]
var demo_arr = ["a","b","c"]
var new_arr = odd_num.concat(demo_arr,even_num,demo_arr,even_num)
console.log(new_arr)



//new york
//. 0.             1.         2.       3
//"California","new york" ,"Paris","Barcelona"

var  City_Name = ["California","Paris","Barcelona","demo1","demo2","demo3","demo4"] 
// City_Name.unshift("New York")
// console.log(City_Name)
// City_Name.splice(1,0,"New York")
// City_Name.splice(2,1,0)
City_Name.splice(2,3)
console.log(City_Name)

//					0.           1.        2	    3.      4.      5
var City_Name = ["California","Paris","Barcelona","demo1","demo2","demo3"] 
// var res = City_Name.slice(1,4)
// var res = City_Name.slice(-1)
var res = City_Name.slice(-5,-1)
console.log(res)


 
var City_Name = ["California","Paris","Barcelona","demo1","demo2","demo3"]
console.log(Array.isArray(City_Name))

 
 City_Name = "California"
console.log(Array.isArray(City_Name))









































