// // this 


function fun1(a){
    // console.log(a)
    // a.style.color = "red";
    // alert(a.title);
   alert(a.getAttribute('colo_name'))

}
function fun2(y){
    // console.log(y.getAttribute('bg_color'))

    var div_tags = document.getElementsByTagName('div');
    for(var j =0;j<div_tags.length;j++){
        div_tags[j].style.background = ""
    }
    
    var final_color = y.getAttribute('bg_color');
    y.style.background = final_color
}

function fun3(z){
    var img_tag = document.getElementsByTagName('img');
    for(var j =0;j<img_tag.length;j++){
        img_tag[j].style.borderRadius = ""
    }
    // console.log(z)
    z.style.borderRadius = "50%"
}

function open_div_fun(x){
    // console.log(x)
    // console.log(document.getElementById(x))

    var box_class_div = document.getElementsByClassName('box');
    for(var j = 0;j<box_class_div.length;j++){
        box_class_div[j].style.display = "none"
    }
    document.getElementById(x).style.display = "block"

}


