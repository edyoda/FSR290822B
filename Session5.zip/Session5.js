


// var emp_info = {
// 	emp1 : {
// 		name : "john",
// 		email : "john@gmail.com",
// 		contact : 7682682
// 	},
// 	emp2 : {
// 		name : "tom",
// 		email : "tom@gmail.com",
// 		contact : 3243432
// 	},
// 	emp3:{
// 		name : "alex",
// 		email : "alex@gmail.com",
// 		contact : 989898988
// 	},
// 	emp4 : {
// 		name : "selena",
// 		email : "selena@gmail.com",
// 		contact : 9876
// 	},
// 	emp5 : {
// 		name : "sam",
// 		email : "sam@gmail.com",
// 		contact : 78787
// 	}
// }



// for(var x in emp_info){
// 	// console.log(x)
// 	// console.log(emp_info[x])
// 	for(var y in emp_info[x]){
// 		// console.log(y)
// 		// console.log(emp_info[x][y])
// 		document.write(y+" -------- "+emp_info[x][y]+"<br>")
// 	}

// 	document.write("<br>**************************************<br>")

// }






// var obj1 = {
// 	name : "tom",
// 	email : "tom@gmail.com",
// 	contact : 5432
// }


// for(var j in obj1){
// 	// console.log(j)
// 	// console.log(obj1[j])

// 	document.write(j+" :- "+obj1[j]+"<br>")
// }








// A falsy value is something which evaluates to FALSE, for instance when checking a variable. 
// There are only six falsey values in avaScript: undefined , null , NaN , 0 , "" (empty string), 
// and false of course.


// In JavaScript, a truthy value is a value that is considered true when encountered in a Boolean context. 
// All values are truthy unless they are defined as falsy. That is, all values are truthy except false , 0 , -0 , 
// 0n , "" , null , undefined , and NaN . JavaScript uses type coercion in Boolean contexts.






var str_obj = {
	str1 : "hello world",
	str2 : "HELLO WORLD"
}
for(var j in str_obj){
	// console.log(str_obj[j])
	if(j=="str1"){
		console.log(str_obj[j].toUpperCase())
	}
	else if(j=="str2"){
		console.log(str_obj[j].toLowerCase())
	}
}























