/*alert(1234);
alert('hiral');
alert("9837493");
alert(true);
alert(false);


console.log("tom");
console.log(1234);
console.log(true);
console.log(false);


prompt("Enter Your Name : ");


var user_name = "John";
alert(user_name);
alert(user_name);
console.log(user_name);



var num1 = 10;
var num2 = 20;
alert(num1+num2);
alert(num1*num2);
alert(num2/num1);
alert(num1-num2);



var str1 = "hello ";
var str2 = " javascript";
alert(str1+str2);


var str3 = "hello";
var str4 = "javascript";
alert(str3+" "+str4);


var user_name = "tom";
var user_age = 13;
//my name is tom and age is 12

alert("my name is "+user_name+" and age is "+user_age);*/




function Hello(){
    alert("hello world !")
}


Hello();
Hello();
Hello();


function add(x,y){
    var ans = x+y;
    alert(ans);
}
add(8,9);
add(12,3);
add(5,9);
add(8,5);
add(2,4);
add(100,300);



function std_info(name,age,subject){
        console.log("std name is "+name+ " std age is "+age+ " std sub is "+subject);
}
std_info("tom",12,"python");
std_info("john",13,"js");
std_info("alex",14,"php");
std_info("selena",20,"es6");













