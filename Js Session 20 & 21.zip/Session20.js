
// function Apple(color,config,os,inch,ram){
//     this.laptop_color = color;
//     this.laptop_config = config;
//     this.laptop_os = os;
//     this.laptop_inch = inch;
//     this.laptop_ram = ram
//     this.getColor = function(){
//         console.log(this.laptop_color)
//     }
//     this.getRam = function(){
//         console.log(this.laptop_ram)
//     } 
//     this.setColor = function(){
//         this.laptop_color = "silver"
//         console.log(this.laptop_color)
//     }  
//     this.setRam = function(){
//         this.laptop_ram = "20gb"
//         console.log(this.laptop_ram)
//     }

// }

// var MyLaptop1 = new Apple("Starlight","m2 512gb","13.0","13","16gb")
// console.log(MyLaptop1)
// MyLaptop1.getColor();
// MyLaptop1.getRam();
// MyLaptop1.setColor();
// MyLaptop1.setRam();
// console.log(MyLaptop1)

// var MyLaptop2 = new Apple("Gold","m1 256gb","12.0","13","8gb")
// console.log(MyLaptop2)
// MyLaptop2.getColor();
// MyLaptop2.getRam();


// var obj1 = {
//     name : "john",
//     email : "john@gmail.com",
//     contact : 87654678
// }
// console.log(obj1)

// hide()

// $(document).ready(function(){
//     // alert(23456)
//     $('button').click(function(){
//         // alert(1234)
//         $('#demo1').hide()
//     })
// })



// $(document).ready(function(){

//     $('#demo2').click(function(){
//       $('#demo3').hide()  
//       $('.test1').hide()
//     })
// });

// $(document).ready(function(){
//     $('#demo4').click(function(){
//         $('#demo3').show();
//         $('.test1').show();
//     })
// })



$(document).ready(function(){
    $('#btn_for_hide').click(function(){
        $('#img1').hide()
    })
})




$(document).ready(function(){
    $('#btn_for_show').click(function(){
        $('#img1').show()
    })
})



























