// $(document).ready(function(){
//     $('#btn1').click(function(){
//         $('#p1').css("background-color","red");
//         $('#p1').addClass("demo_style")
//     })
// })


// $(document).ready(function(){
//     $('#btn2').click(function(){
//         $("#p1").removeClass('demo_style');
//     })

// })

// $(document).ready(function(){
//     $('#btn3').click(function(){
//         $("#vidya,h2,h3,div").toggleClass('demo_style')
//     })
// })

// $(document).ready(function(){
//     $('#btn4').click(function(){
//         $('img').toggleClass('img_style');
//     })
// })


// $(document).ready(function(){
//     $('#btn5').click(function(){
//         $('b').first().css("color","blue");
//         $('b').last().css("color","blue");
//         $('b').eq(2).css("color","blue");
//         $('b').filter('.filter_class').css("color","yellowgreen");
//     })
// })


// fadeIn
// fadeOut
// toggle
// slideup
// slidedown
// slidetoggle
// stop (for slide)


// $(document).ready(function(){
//     $('#btn6').click(function(){
//         $('#demo4').fadeIn("fast")
//         $('#demo1').fadeIn()
//         $('#demo2').fadeIn("slow")
//         $('#demo3').fadeIn(3000)
//     })
// })


// $(document).ready(function(){
//     $('#btn7').click(function(){
//         $('#demo5').fadeOut("fast")
//         $('#demo6').fadeOut()
//         $('#demo7').fadeOut("slow")
//         $('#demo8').fadeOut(3000)
//     })
// })

// $(document).ready(function(){
//     $('#btn8').click(function(){
//         $('p').toggle()
//     })
// })




$(document).ready(function(){
    // $('#slide_div1').mouseover(function(){
    // $('#slide_div1').mouseout(function(){
    // $('#slide_div1').click(function(){
    $('#slide_div1').dblclick(function(){
        // $('#slide_div2').slideDown("fast")
        // $('#slide_div2').slideDown("slow")
        // $('#slide_div2').slideDown(3000)
        $('#slide_div2').slideDown()
    })
})


$(document).ready(function(){
    $('#slide_div3').click(function(){
        // $('#slide_div4').slideUp()
        // $('#slide_div4').slideUp("fast")
        // $('#slide_div4').slideUp("slow")
        // $('#slide_div4').slideUp(3000)
        // $('#slide_div4').slideToggle();
        // $('#slide_div4').slideToggle('slow');
        // $('#slide_div4').slideToggle('fast');
        $('#slide_div4').slideToggle(5000);
    })

    $('#btn9').click(function(){
        $('#slide_div4').stop()
    })
})




















