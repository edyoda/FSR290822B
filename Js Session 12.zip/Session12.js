

/*

function fun1(){
//   var x =  document.querySelectorAll('#list1 li')
//   console.log(x)
    // var x = document.querySelectorAll("#list1 > a")
    for(var j =0;j<x.length;j++){
        x[j].style.color = "red";
    }
}

function fun2(){
    var y = document.querySelectorAll(".demo_para ~ p")
    // console.log(y)
    for(var z =0;z<y.length;z++){
        y[z].style.color = "blue"
    }
}



function fun3(){
//   var z =   document.querySelector("b")
var z = document.querySelector('.xyz')
  console.log(z)
// z.style.color="pink"
}*/






// function add_bg_color(){
//     // alert(12345)
//     document.getElementById('div1').style.background = "pink";
// }


// function remove_bg_color(){
//     document.getElementById('div1').style.background = ""
// }

// function add_bg_img1(){
//     document.getElementById('div2').style.background = "url(img1.jpg)"
//     document.getElementById('div2').style.backgroundSize = "cover";
// }

// function add_bg_img2(){
//     document.getElementById('div2').style.background = "url(img2.jpg)";
//     document.getElementById('div2').style.backgroundSize = "cover";
// }





// function fun4(){
//     alert("hello")
// }


// function fun5(){
//     document.getElementById('div4').style.backgroundColor = "yellowgreen"
// }


// function fun6(){
//     document.getElementById('div5').style.backgroundColor = "pink"
// }



// function fun7(){
//     var user_input = document.getElementById('input1').value;
//     document.getElementById('ans1').innerHTML = user_input
//     document.getElementById('input1').style.color = "red"
// }





// function fun8(){
//     document.getElementById('ans2').style.color = "blue"
// }

// function fun9(){
//     document.getElementById('ans2').style.color = "red"
// }
// function fun9(){
//     document.getElementById('ans3').style.border="2px solid red"
// }

// function fun10(){
//     document.getElementById('ans3').style.color = "hotpink"
// } 
// function fun11(){
//     var x = document.getElementById('input3')
//     // x.value = x.value.toupperCase()
//    x.value = x.value.toUpperCase()
// }



// function fun12(){
//     var selected_value =  document.getElementById('input4').value;
//     document.getElementById('ans4').innerHTML = selected_value
// }







var btn_tag = document.getElementById('btn1');
btn_tag.addEventListener("click",fun13);
btn_tag.addEventListener("mouseover",fun14);
btn_tag.addEventListener("mouseout",function(){
    document.getElementById('div6').style.background = "pink"
})


function fun13(){
    document.getElementById('div6').innerHTML += "click event with addEventListener <br>"
}

function fun14(){
    document.getElementById("div6").innerHTML += "over event with addEventListener <br>"
}


























