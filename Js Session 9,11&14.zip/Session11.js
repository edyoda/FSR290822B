

// console.log(document.getElementById('demo1'))

// var para1 = document.getElementById('demo1').innerHTML;
// // console.log(para1)
// document.getElementById('demo2').innerHTML = para1;


// function fun1(){
   
//     var div1_data = document.getElementById('demo3').innerHTML
//     var div2_data = document.getElementById('demo4').innerHTML
//     // console.log(div1_data,div2_data)
//     document.getElementById('demo3').innerHTML = div2_data
//     document.getElementById('demo4').innerHTML = div1_data
// }



// var x = prompt("Enter Your Name :")

// document.getElementById('read_prompt').innerHTML = x



// function add_bg_color(){
//     document.getElementById('div1').style.background = "red";
//     document.getElementById('div1').style.borderRadius = "50%";
//     document.getElementById('div1').style.boxShadow = "2px 13px green"

// }

// function add_text_style(){
//     document.getElementById('div2').className = "text_styling"
// }





// function read_input_value(){
//     var user_input = document.getElementById('input1').value;
//     // console.log(user_input)
//     // alert(user_input)
//     document.getElementById('read_input_value').innerHTML  += user_input
// }




// function sum_fun(){
//     var num1 = document.getElementById('user_num1').value;
//     var num2 = document.getElementById('user_num2').value;
//     var final_ans = Number(num1)+Number(num2);
//     document.getElementById('add_ans').innerHTML += final_ans


// }



// function H1_Tags_Reading(){
//     var h1_tags = document.getElementsByTagName('h1');
//     // console.log(h1_tags)
//     for(var x = 0;x<h1_tags.length;x++){
//         // h1_tags[x].style.color = "blue"
//         h1_tags[x].className = "text_styling"
//     }
// }


// function by_class_name(){
//     var y = document.getElementsByClassName("pqr");
//     // console.log(y)
//     for(var j = 0;j<y.length;j++){
//         y[j].style.border = "3px solid black"
//     }
// }


