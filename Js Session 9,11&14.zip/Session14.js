// var a;
// function fun1(){
//     a = setInterval(callback_fun,2000)
// }

// function callback_fun(){
//     alert("hey how are you ?")
// }

// function fun2(){
//     clearInterval(a)
// }

// var z = document.getElementById('btn1');
// z.addEventListener('click',main_fun)


// function main_fun(){
//     setTimeout(()=>{
//         document.getElementById('div1').style.background = "url(img1.jpg)"
//         document.getElementById('div1').style.backgroundSize = "cover"
//     },3000)
// }


//return keyword

// function add(x,y){
//     var ans = x+y
//     document.write(ans)
// }
// add(2,4)


// function add(x,y){
//     var ans = x+y
//     return ans
// }
// // var x = add(5,8);
// // document.write(x)


// function user_input_addition(){
//     var num1 = Number(prompt("Enter a num1"))
//     var num2 = Number(prompt("Enter a num2"))
//     var x = add(num1,num2)
//     document.write(x)
// }

// user_input_addition()


// function dom_input_fun(){
//     var user_input1 = Number(document.getElementById('demo1').value)
//     var user_input2 = Number(document.getElementById('demo2').value)
//     var y = add(user_input1,user_input2)
//     document.getElementById('ans1').innerHTML = y
// }
// var max_val;
// function max_num(a,b,c){
//     if(a>b && a>c){
//         max_val = a
//     }
//     else if(b>a && b>c){
//         max_val = b
//     }
//     else if(c>a && c>b){
//         max_val = c
//     }
//     return max_val
// }
// var res = max_num(89,99,90)
// document.write(res)


// function vowel_count(word){
//     var count = 0;
//     for(var j =0;j<word.length;j++){

//         if(word[j]=="a" || word[j]=="i"||word[j]=="o"||word[j]=="e"||word[j]=="u"){
//             count = count+1
//         }
//     }
//     return count;


// }
// function read_fun(){
//     var user_input = document.getElementById('input1').value;
//     var res = vowel_count(user_input)
//     document.write(res)

// }




// function validate(){
//     var name_input = document.getElementById('name_id');
//     var password_input = document.getElementById('password_id');
//     var flag = true;

//     if(name_input.value.trim()==""){
//         document.getElementById('name_error').innerHTML = "Blank error : kindly add your name"
//         // alert("Blank error : kindly add your name")
//         name_input.style.border = "3px solid red"
//         flag = false;
//     }
//     else if(name_input.value != ""){
//         document.getElementById('name_error').innerHTML = ""
//         name_input.style.border = ""
//     }

//     if(password_input.value.trim()==""){
//         // alert("Blank error : kindly add your password")
//         document.getElementById('password_error').innerHTML = "Blank error : kindly add your password"
//         password_input.style.border = "3px solid red"
//         flag = false;
//     }
//     else if(password_input.value != ""){
//         document.getElementById('password_error').innerHTML = ""
//         password_input.style.border = ""
//     }

//     // alert(flag)
//     return flag 


// }




var info={
    'data1':[ {'name':'student1','email':'student1@gmail.com','contact':123}, {'name':'student2','email':'student2@gmail.com','contact':123} ],
    'data2':[ {'name':'student3','email':'student3@gmail.com','contact':123}, {'name':'student4','email':'student4@gmail.com','contact':123} ]
    }

for(var i in info){
    // console.log(info[i])
    for(var j=0;j<info[i].length;j++){
        // console.log(info[i][j])
        var div_tag = document.createElement('div')
        div_tag.className = "div_style";
        // console.log(div_tag)
        for(var x in info[i][j]){
            // console.log(info[i][j][x])
            div_tag.innerHTML += info[i][j][x]+"<br>"
        
        }

        document.getElementById('demo_div').appendChild(div_tag)
        // console.log(div_tag)
     
    }

}











