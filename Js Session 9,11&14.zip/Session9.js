// alert(1234);
// alert(1234);
// alert(1234);
// alert(1234);
// alert(1234);
// alert(1234);

// hello_fun();
// hello_fun();
// hello_fun();
// hello_fun();
// hello_fun();



// function hello_fun(){
// 	document.write("Hello how are you ?<br>")
// }
// hello_fun();
// hello_fun();
// hello_fun();
// hello_fun();
// hello_fun();
// hello_fun();


// function demo_fun(){
// 	// alert(12345);
// 	// console.log(document.getElementById('demo1'))
// 	document.getElementById('demo1').style.background="red";

// }

// demo_fun()


// var div_tag = document.getElementById('demo2');
// // console.log(div_tag)
// div_tag.onclick  = function(){
// 	div_tag.style.background = "url(img1.jpg)";
// 	div_tag.style.backgroundSize = "cover";
// }








// abc();
// abc();
// abc();



// var abc = ()=>document.write("hey this is my first fat arrow function <br>")
// abc();

// var add = (x,y)=>{
// 	var ans1 = x+y
// 	document.write(ans1)
// }
// add(12,1)



// fun1()
// fun1()
// fun1()
// fun1()


// function fun1(){
// 	document.write("demo data <br>")
// }



// fun1()
// fun1()
// fun1()
// fun1()


// document.write(x)
// var x = 12;



// var add = (x,y)=>{
// 	var ans1 = x+y
// 	document.write(ans1+"<br>")
// }

// add(10,20);
// add(2,3);
// add(8,9);
// add(2,9);




// document.write(x);
// var x = 12


// var fun1 = ()=>{
// 	document.write("hello")
// }

// fun1()



// var btn_fun1 = ()=>{
// 	document.getElementById('demo_btn1').style.background = "red"
// }


// var btn_tag = document.getElementById('demo_btn2');
// btn_tag.onclick = ()=>{
// 	btn_tag.style.background = "blue"
// }








// var modal_div = document.getElementById('modal_div_1');

// function open_modal_fun(){

// 	modal_div.style.display = "flex";
// }


// function close_modal_fun(){
// 	modal_div.style.display = "none";
// }




// var x = 12;
// function var_demo_fun1(){
// 	// var x = 12;
// 	document.write(x)

// }
// var_demo_fun1()


// function var_demo_fun2(){
// document.write(x)
// }

// function var_demo_fun3(){
// 	document.write(x)
// }

// var_demo_fun2()
// var_demo_fun3()









// var p_tag = document.getElementById('para1');
// p_tag.onclick = ()=>{
// 	p_tag.style.color = "blue"
// } 





var obj1 = {
	name : "john",
	email : "john@gmail.com",
	contact : 76543

}



// document.write(obj1)
// document.write(obj1.name+"<br>"+obj1.email+"<br>"+obj1.contact+"<br>")

for(var i in obj1){
	console.log(i)
	console.log(obj1[i])
}



