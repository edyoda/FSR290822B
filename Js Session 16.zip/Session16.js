function read_post(){

    var a = new XMLHttpRequest();
    a.open("GET",'https://jsonplaceholder.typicode.com/posts',true);
    a.send();
    a.onreadystatechange = function(){
         if(this.status == 200 && this.readyState  == 4){
        // console.log(this.responseText)
        var data = this.responseText
        // console.log(typeof(data))
        // console.log(data)
        var final_data = JSON.parse(data)
        // console.log(typeof(final_data))
        // console.log(final_data)

            for(var j =0;j<final_data.length;j++){
                // console.log(final_data[j])
                for(var i in final_data[j]){
                   document.getElementById('demo1').innerHTML += i+" ----- "+final_data[j][i]+"<br>"
                }

                document.getElementById('demo1').innerHTML += "<br>*************************<br><br>"

            }

    }
    }

}

read_post()