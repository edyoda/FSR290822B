// document.write("hello");


// function read_para_tag() {
// 	var p_tag = document.getElementById('demo1').innerHTML;
// 	// console.log(p_tag);
// 	alert(p_tag);
// }


// function add_para_fun(){
// 	document.getElementById('demo2').innerHTML = "new para"
// } 





// var m = "12";
// var n = 12;
// var k = m == n;
// var k = m>n;
// var k = m<n;
// var k = m>=n;
// var k = m<=n;
// var k = m!=n;
// var k = m===n;
// alert(k);


// var age = 20;
// if(age>=18){
// 	document.write("you are eligible for vote");
// }
// else{
// 	document.write("you are not eligible for vote");
// }


// var x = 5;
// if(x == 5){
// 	document.write("x is 5");
// }
// else if(x==30){	
// 	document.write("x is 30");
// }
// else if(x==50){
// 	document.write("x is 50");
// }
// else if(x==60){
// 	document.write("x is 60");
// }
// else{
// 	document.write("from else x is "+x);
// }

// // 5-10
// // >=5     <=10
// // 5,6,7,8,9,10


// var num1 = 50;
// if(num1>=5 && num1<=10){
// 	document.write("the num is in bet 5-10 range");
// }
// else if(num1==50 || num1==60){
// 	document.write("the num is "+num1);
// }

// else{
// 	document.write("sorry not in range");
// }



// var y = "i";
// // aeiou
// if(y=="a" || y=="i" | y=="u" ||y=="e"||y=="o"){
// 	document.write("y is vowel");
// }
// else{
// 	document.write("y is not a vowel")
// }





// var num2 = prompt("Enter a number");
// if(num2>0){
// 	document.write("num is +ve");
// }
// else if(num2<0){
// 	document.write("num is -ve");

// }
// else if(num2 ==0){
// 	document.write("num is zero");
// }
// else{
// 	document.write("sorry wrong input");
// }

// alert(9/2);
// alert(9%2);



// var num3 = 22;
// // alert(num3%5)
// if(num3%5==0){
// 	document.write("the num is divisible by 5");
// }
// else{
// 	document.write("ths num is not divisible by 5");
// }


// var num4 = prompt("Enter a number");
// if(num4%2==0){
// 	document.write("num is even");
// }
// else if(num4%2!=0){
// 	document.write("num is odd");
// }



// ** power

// var num5 = 8
// alert(num5**2);

// var num6 = 5;
// alert(num6**3)


// alert(2*2);
// alert(16/2);
// alert(16%2);



// var  num7 = prompt("Enter a number")
// if(num7%2==0){
// 	document.write(num7**2);
// }
// else if(num7%2!=0){
// 	document.write(num7**3);
// }
// else{
// 	document.write("sorry");
// }

// ternary




var age = 15;
var ans1 = (age>=18) ? "you are eligible for vote" : "you are not eligible for vote"
document.write(ans1)



// exp ? true : false

var marks = 20;
var ans2 = (marks>=35) ? "pass" : "fail";
document.write(ans2);











































