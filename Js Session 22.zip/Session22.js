
// var productload = ()=>{
//     var a = new XMLHttpRequest();
//     a.open('GET','https://fakestoreapi.com/products/',true)
//     a.send()
//     a.onreadystatechange = function(){
//         if(this.status == 200 && this.readyState == 4){
//             // console.log(this.responseText)
//             var data = JSON.parse(this.responseText)
//             // console.log(data)
//             for(var j =0;j<data.length;j++){
//                 // console.log(data[j])
//                 var div_tag = document.createElement('div')
//                 div_tag.className = "product_div"
//                 for(var i in data[j]){
//                     // console.log(data[j][i])
//                     if(i=="image"){
//                         var img_tag = document.createElement('img');
//                         img_tag.src = data[j][i]
//                         // console.log(img_tag)
//                         img_tag.className = "img_style"
//                         div_tag.appendChild(img_tag)
//                     }
//                     else{
//                         div_tag.innerHTML += "<br>"+i+" --- "+data[j][i]+"<br><br>"
//                     }
                   
                  
//                 }
//                 // console.log(div_tag)
//                 document.getElementById('demo1').appendChild(div_tag)
//             }
//         }
//     }

// }

// productload();





// $.get() // for ajax api call

// var productload = ()=>{
//     $.get('https://fakestoreapi.com/products',function(data,status){
//         // console.log(data)
//         // console.log(status)
//         // forEach
//         data.forEach((element)=>{
//             // console.log(element)
//             var div_tag = document.createElement('div');
//             div_tag.className = "div_style"
//             for(var j in element){
//                 // console.log(element[j])
//                 // document.write(element[j])
//                 if(j=="image"){
//                    var img_tag = document.createElement('img');
//                    img_tag.src = element[j]
//                    img_tag.className = "img_style"
//                    div_tag.appendChild(img_tag)
//                 }
//                 else{
//                     div_tag.innerHTML += element[j]+"<br>"
//                 }
               
//             }

//             document.getElementById('demo1').appendChild(div_tag)

//         })


//     })
// }

// productload()


// $.post() // for ajax api call


// var new_prodcut = {
//     "id": 21,
//     "title": "red dress",
// "price": 500,
// "description": "Red dress dataRed dress dataRed dress dataRed dress dataRed dress data ",
// "image" : "https://cdn.vectorstock.com/i/1000x1000/62/76/red-dress-vector-23096276.webp"
// }


// $.post('https://fakestoreapi.com/products/',new_prodcut,function(data,status){
//     console.log(data)
//     // console.log(status)
//    for(var j in data){
//     if(j=="image"){
//         document.getElementById('img1').src = data[j]
//     }
//     else{
//         document.getElementById('demo2').innerHTML += data[j]+"<br>"
//     }
//    }
// })



// class Animal{
//     constructor(name){
//         this.name = name
//     }
//     getPetName(){
//         return "Name is : "+this.name
//     }
// }

// class Dog extends Animal{
//     constructor(name){
//         super(name)
//     }
//     printPet(){
//         return "this is dog and his "+super.getPetName()
//     }
// }
// class Cat extends Animal{
//     constructor(name){
//         super(name)
//     }
//     catName(){
//         return "this is cat and her "+super.getPetName()
//     }
// }
// var pet1 = new Dog("tom")
// console.log(pet1.printPet())
    
// var pet2 = new Cat("kitty")
// console.log(pet2.catName())



// class Person{
//     constructor(name){
//         this.name = name;
//     }
//     goal(){
//         return this.name+ " wants to become a Chef !"
//     }
//     interest(){
//         return this.name+ " interested in cooking"
//     }
// }

// class Student extends Person{
//     constructor(name){
//         super(name);
//     }
//     need(){
//         return this.name+ " needs a cooking kit;"
//     }
//     info(){
//         return [super.interest(),
//                 super.goal(),
//                 this.need()];
//     }
    

// }

// var std1 = new Student("ganesh");
// document.write(std1.info()+"<br>");



class Student{
    constructor(){
        var name,marks;
    }
    getName(){
        console.log(this.name)
    }
    setName(std_name){
        this.name = std_name   
    }
    setMarks(std_marks){
        this.marks = 90
    }
    getMarks(){
        console.log(this.marks)
    }


    
}
var obj1 = new Student()
obj1.setName("john")
obj1.getName()
obj1.setMarks(90)
obj1.getMarks()













































