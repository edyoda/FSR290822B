// var num1 = prompt("Enter num1");
// var num2 = prompt("Enter num2");
// if(num1==num2){
// 	var ans = Number(num1) + Number(num2)
// 	document.write(ans)
// }
// else if(num1!=num2){
// 	document.write(num1-num2);
// }



// var a = "hello";
// switch(a){
// 	case 1: 
// 	document.write("inside case 1");
// 	break
// 	case 2:
// 	document.write("inside case 2");
// 	break;
// 	case 3:
// 	document.write("inside case 3");
// 	break;
// 	case 4:
// 	document.write('inside case 4');
// 	break;
// 	case "hello":
// 	document.write("inside hello case");
// 	break;
// 	default:
// 	document.write('default case');
// }

// var num1 = Number(prompt("Enter a num1"))
// var num2 = Number(prompt("Enter a num2"))
// var result1 = num1 == num2
// console.log(result1)
// switch(result1){
// 	case true :
// 	document.write(num1+num2)
// 	break;
// 	default:
// 	document.write(num1-num2)
// }








// object literal



// var person = {
// 	subject : "js,react js",
// 	subject1 : "python",
// 	sk_sub : "css",
// 	sk_sub1 : "css",
// 	sk_sub2 : "css",
// 	sk_sub3 : "css",
// 	new_data : 12343
// };
// // console.log(typeof(person));
// // person.firstName = "john";
// // person.lastName = "Doe";
// // person.age = 20;
// // person.subject2 = "python"
// person.new_data = 999




// console.log(person)






// var person_info = {};
// person_info.firstName = "Selena";
// person_info.lastName = "Gomez";
// person_info.age = 12;
// person_info.subject = "css";

// // document.write(person_info)
// document.write("First Name is :- "+person_info.firstName+"<br>");
// document.write("Last Name is :- "+person_info.lastName+"<br>");
// document.write("Age is :- "+person_info.age+"<br>");
// document.write("subject is :-"+person_info.subject+"<br>");



// new Object()

// var person = new Object();
// person.City_name = "mumbai"
// person.subject = "php";
// // console.log(person)
// document.write(Object.entries(person)+"<br>");
// document.write(Object.keys(person)+"<br>");
// document.write(Object.values(person)+"<br>");




// var obj1 = {
// 	name : null,
// 	email : "tom@gmail.com",
// 	contact :4321234,
// 	marks : 80
// }

// obj1.City_name = "mumbai"
// obj1.name = "ganesh"
// // delete obj1.contact
// delete obj1["contact"]



// console.log(obj1)





// var obj2 = {
// 	name : "tom",
// 	email : "tom@gmail.com",
// 	contact :4321234,
// 	marks : 80,
// 	subject : "Js",
// 	City_name : "mumbai"
// }
// // document.write(obj2.name+"<br>"+obj2.email+"<br>"+obj2.email+"<br>"+obj2.contact+"<br>"+obj2.marks+"<br>"+obj2.subject+"<br>"+obj2.City_name+"<br>");




// for(var i in obj2){
// 	// document.write(i +" :- "+obj2[i]+"<br>")
// 	if(i=="email"){
// 		document.write(i+" :- "+obj2[i])
// 	}
// }

