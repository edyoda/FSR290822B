// In computer programming, a loop is a sequence of instructions that 
// is continually repeated until a certain condition is reached.
 
//  For example, when you are displaying number from 1 to 100 you may want 
//  set the value of a variable to 1 and display it 100 times, increasing 
//  its value by 1 on each loop iteration.






/*
document.write("hiral 1 <br>");
document.write("hiral 2 <br>");
document.write("hiral 3 <br>");
document.write("hiral 4 <br>");
document.write("hiral 5 <br>");
document.write("hiral 6 <br>");
document.write("hiral 7 <br>");
document.write("hiral 8 <br>");
document.write("hiral 9 <br>");
document.write("hiral 10 <br>");


//. ------1--- ---2-- ---4----
for(var box =1;box<=5;box=box+1){
	document.write("Object is inside box "+box+"<br>") //------3-------
}


for(var user_name = 1;user_name<=10;user_name=user_name+1){
	document.write("hiral "+user_name+"<br>")
}
*/




// for(var user_name=10;user_name>=1;user_name=user_name-1){
// 	document.write("Hiral "+user_name+"<br>")
// }



// for(var box = 5;box>=1;box = box-1){
// 	document.write("Object is inside box "+box+"<br>")
// }









// 10
// 20
// 30
// 40
// 50
// 60
// 70
// 80
// 90
// 100



// for(var x=10;x<=100;x=x+10){
// 	document.write(x+"<br>")
// }


// for(var x=25;x<=250;x=x+25){
// 	document.write(x+"<br>")
// }

// 10*1=10
// 10*2=20
// 10*3=30
// .....
// 10*10=100



// for(var z=1;z<=10;z=z+1){
// 	document.write(25*z+"<br>")
// }
// for(var z=1;z<=10;z=z+1){
// 	document.write(10*z+"<br>")
// }










//			0123456789012345678901234
// var str1 = "hello javascript"
// h
// e
// l
// l
// o

// j
// a
// v
// a
// s
// c
// r
// i
// p
// t
// document.write(str1[0]+"<br>");
// document.write(str1[1]+"<br>");
// document.write(str1[2]+"<br>");
// document.write(str1[3]+"<br>");
// document.write(str1[4]+"<br>");
// document.write(str1[5]+"<br>");
// document.write(str1[6]+"<br>");
// document.write(str1[7]+"<br>");
// document.write(str1[8]+"<br>");
// document.write(str1[9]+"<br>");
// document.write(str1[10]+"<br>");
// document.write(str1[11]+"<br>");
// document.write(str1[12]+"<br>");
// document.write(str1[13]+"<br>");
// document.write(str1[14]+"<br>");

// for(var x=0;x<=15;x=x+1){
// 	document.write(str1[x]+"<br>")
// }

// for(var x=0;x<str1.length;x=x+1){
// 	document.write(str1[x]+"<br>")
// }








// var z = prompt("Enter Your Name :")
// // console.log(z)
// for(var x =0;x<z.length;x=x+1){
// 	if(z[x]=="a" ||z[x]=="o"||z[x]=="e"||z[x]=="i"||z[x]=="u"){
// 		console.log(z[x])
// 	}
// }

//			0. 1. 2.  3  4 5. 6. 7. 8 9

// var arr1 = [11,12,13,14,15,16,17,18,19,20]
// for(var x=0;x<arr1.length;x=x+1){
// 	// console.log(arr1[x])
// 	if(arr1[x]%2!=0){
// 		console.log(arr1[x])
// 	}
// }


var obj1 = {
	name : "john",
	email : "john@gmail.com",
	car_list : {
		most_fav_car :  ['Audi', 'Toyota',"Bugatti","Volvo"]
														
	}
}


for(var i in obj1.car_list.most_fav_car){
	// console.log(obj1.car_list.most_fav_car[i])
	if(obj1.car_list.most_fav_car[i]=="Toyota"){
		console.log(obj1.car_list.most_fav_car[i])
	}
}


// for(var i in obj1.car_list){
// 	console.log(obj1.car_list[i])
// }






















