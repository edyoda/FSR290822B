// function fun1(){
//     var li_tag = document.createElement("li");
//     // console.log(li_tag);
//     var li_text = document.createTextNode("xyz");
//     // console.log(li_text);
//     li_tag.appendChild(li_text)
//     // console.log(li_tag)
//     document.getElementById('list1').appendChild(li_tag)
 
// }


// function add_img_fun(){
//     for(var j =1;j<=3;j++){
//       var img_tag =  document.createElement("img");
//       img_tag.src = "img1.jpg"
//     //   console.log(img_tag) 
//     document.getElementById('div1').appendChild(img_tag)
//     }
// }



// var btn1 = document.getElementById('demo1');
// btn1.addEventListener("click",add_para_fun)

// function add_para_fun(){
//     var p_tag = document.createElement('p');
//     var para_text = document.createTextNode("lorm ipsumlorm ipsumlorm ipsumlorm ipsumlorm ipsumlorm ipsumlorm ipsumlorm ipsum")
//     p_tag.appendChild(para_text)
//     document.getElementById('div2').appendChild(p_tag)
// }




// function remove_fun1(){
//     var ul = document.getElementById('list2');
//     var temp_var = ul.childNodes[0]
//     // console.log(temp_var)
//     // ul.removeChild(ul.childNodes[0])
//     ul.remove();
// }





// function remove_li(x){
//     // console.log(x)
//     document.getElementById(x).remove();
// }


// function remove_row(){
//     // var x = document.getElementById('Child_btn');
//     // console.log(x.parentNode.parentNode)
//     // var row = x.parentNode.parentNode;
//     // console.log(row.parentNode)
//     // row.parentNode.removeChild(row);
//     document.getElementById('row1').remove()
// }




// function my_fun1(){
//     setTimeout(function(){
//         alert("javascript is fun")
//     },2000)
// }





// function my_fun1(){
//     setTimeout(hello_fun,3000);
//     document.getElementById('ans1').innerHTML = "demo message without any timers"

// }

// function hello_fun(){
//     alert("hello how are you ?")
// }

// function first() {
//     console.log('first');
// }
// function second() {
//     console.log('second');
// }
// function third() {
//     console.log('third');
// }
// first();
// setTimeout(second, 1000);
// third();



















