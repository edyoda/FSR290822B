//.   		0. 1 	
// var arr1 = [11,12,13,14,15,16,17,25,30,35,40,45,18,19,20]
// for(var z =0;z<arr1.length;z=z+1){
// 	// document.write(arr1[z]+"<br>")
// 	if(arr1[z]%5==0){
// 		document.write("sorry it is div by 5<br>");
// 		break;
// 	}
// 	else{
// 		document.write(arr1[z]+"<br>");
// 	}
// }

// var arr2 = [1,10,10,13,10,2,3,2,4,2,5,2,6,2,7,2,8,2,9,2,10,2,11,2,2,2,2,2,2,2,12,13]
// //1 3 4 5 6 7 8 9 10 11 12 13

// for(var c =0;c<arr2.length;c=c+1){
// 	if(arr2[c]==2){
// 		continue;
// 		// break;
// 		// document.write("sorry <br>")
// 	}
// 	else{
// 		document.write(arr2[c]+"<br>");
// 	}


// 	// if(arr2[c]==10){
// 	// 	document.write(arr2[c]+"<br>")
// 	// }
// }

// var arr3 = [1,10,10,13,10,2,3,2,4,2,5,2,6,2,7,2,8,2,9,2,10,2,11,2,2,2,2,2,2,2,12,13]
// for(var j =0;j<arr3.length;j=j+1){
// 	if(arr3[j]%2==0){
// 		continue;
// 	}
// 	else{
// 		document.write(arr3[j]+"<br>")
// 	}
// }




// var user_input = Number(prompt("Enter a number "))
// for(var z = 1;z<=user_input;z=z+1){
// 	var ans1 = z*10
// 	if(ans1 > 100){
// 		document.write("sorry")
// 		break;
// 	}
// 	else {
// 		document.write(ans1+"<br>")
// 	}
// }





// // 1-10
// var i =1;   //------1
// while(i<=10){ //-----2
// 	document.write(i+"<br>"); ////-----3
// 	i = i +1. ////-----4
// }
// //			0
// var str1 = "Hello world new data";
// // H
// // e
// // l
// // l
// // o

// // w
// // o
// // r
// // l
// // d

// var x = 0
// while(x<str1.length){
// 	document.write(str1[x]+"<br>");
// 	x = x+1;
// }




// do while

/*
var z = 1;  //----1
do{ ///-----2
	document.write(z+"<br>");//-222
	z=z+1 //-----3
}
while(z<=20)////-------4



var z = 31;  //----1
do{ ///-----2
	document.write(z+"<br>");//-222
	z=z+1 //-----3
}
while(z<=20)////-------4





var y = 11;
do{
	if(y>10){
		document.write("sorry but code will not work y is > 10")
	}
	else{
		document.write(y+"<br>")
	}
	y=11+1
}
while(y<=10)*/





// var user_input = prompt("How many candies you want ?")
// var i = 1;
// var av = 5;
// while(i<=user_input){
// 	if(i>av){
// 		document.write("sorry out of stock <br>");
// 		break;
// 	}


// 	document.write("candy "+i+"<br>");
// 	i = i +1
// }
//.         0
// var arr4 = [1,10,10,13,10,2,3,2,4,2,5,2,6,2,7,2,8,2,9,2,10,2,11,2,2,2,2,2,2,2,12,13]

// var x =0

// while(x<arr4.length){

// 	if(arr4[x]==2){

// 		continue;
// 	}
// 	else{
// 		x = x+1
// 		document.write(arr4[x]+"<br>");
// 	}
// 	// x = x+1
// }





// var x = 12;
// function hello_fun(){
// 	document.write("Hello Guys How are you? <br>");
// }


// hello_fun();

// hello_fun();


// hello_fun();


// hello_fun();


// hello_fun();


// hello_fun();


// hello_fun();


// hello_fun();



// function add(x,y){
// 	var ans1 = x+y;
// 	document.write(ans1+"<br>");
// }

// add(10,20);
// add(2,8);
// add(5,9);
// add(4,6);
// add(12,13);



function demo_fun(){
	alert("Lorem Ipsum is simply dummy text of the printing and typesetting industry. ... To take a trivial example, which of us ever undertakes laborious physical ...")
}

// demo_fun();
























































